package P;

class A {};

class B {};

public class ShouldBePackage {};
