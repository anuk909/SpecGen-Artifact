interface Ambiguous {};

class C {};

