package javafe.parser;

public class FileFormatException extends java.io.IOException {
  private static final long serialVersionUID = -6923801838876618362L;
  
  public FileFormatException(String msg) { super(msg); }
}
