package javafe.ast;

public interface IdPragma {

	Identifier id();
}
