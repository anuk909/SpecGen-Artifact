package p;

class Private {}
