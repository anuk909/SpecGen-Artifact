class Master extends Referenced {}	// load Referenced.java indirectly
