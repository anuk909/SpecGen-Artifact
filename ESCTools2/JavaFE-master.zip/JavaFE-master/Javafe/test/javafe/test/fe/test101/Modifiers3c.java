class Top {
    void foo() {
	final interface         // parse error (ok, I guess...)
	    FinalInterface {}
    }
}
