// Test illegal import statements

import p.NoSuchPackage.q.*;	// error

class Package2 {}
