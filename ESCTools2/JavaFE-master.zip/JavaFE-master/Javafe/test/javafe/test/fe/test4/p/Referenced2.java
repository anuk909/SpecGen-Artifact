// The wrong package name!

class Referenced2 {}
