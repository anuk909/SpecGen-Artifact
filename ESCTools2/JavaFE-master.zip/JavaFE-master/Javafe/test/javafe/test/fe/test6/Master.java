// Check error reporting for I/O errors when reading source files

// This class just serves to force indirectly loading the type ErrorFile:
class Master extends ErrorFile {}
