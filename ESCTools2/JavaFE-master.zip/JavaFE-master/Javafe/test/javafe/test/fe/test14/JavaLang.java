package p;

import Exception;	// erroneous because <unnamed>.Exception does not exist

class JavaLang {}
