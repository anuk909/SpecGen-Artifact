// Test illegal import statements

import p.NoSuchClass;			// error

public class Single {}
