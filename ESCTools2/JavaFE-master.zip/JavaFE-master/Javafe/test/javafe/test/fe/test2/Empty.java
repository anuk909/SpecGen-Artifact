package p;

/*
 * This test checks to make sure a Tool handles a file with no types
 * properly.
 */
