package p;

public class Test { public static int x; }
