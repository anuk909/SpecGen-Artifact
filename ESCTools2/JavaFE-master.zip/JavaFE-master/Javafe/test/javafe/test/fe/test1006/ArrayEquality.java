class ArrayEquality {

    boolean foo(String[] a, String[] b) {

	return a.equals(b);		// Ok
    }
}
