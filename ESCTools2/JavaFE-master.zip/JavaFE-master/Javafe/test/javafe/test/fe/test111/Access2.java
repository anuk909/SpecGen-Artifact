class U {
    Object x = new a.T();       // error

    Object y = new a.T() {} ;   // legal since comes from a subclass...
}
