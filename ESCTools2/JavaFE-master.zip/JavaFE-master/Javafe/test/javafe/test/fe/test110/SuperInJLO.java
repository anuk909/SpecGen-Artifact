package java.lang;

class Object {

    int x;

    void m() {
	super.x = x;
    }
}
