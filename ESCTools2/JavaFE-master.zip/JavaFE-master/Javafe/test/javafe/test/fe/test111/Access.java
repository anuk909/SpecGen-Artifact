package a;

/**
 ** Verify we use the right class when checking the access of a
 ** constructor for an anonymous class.
 **
 ** This file should be sourced with Access2.java
 **/

public class T {
    protected T() {}
}
