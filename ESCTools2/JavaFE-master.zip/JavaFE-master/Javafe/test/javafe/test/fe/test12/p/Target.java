package p;

public class Target {}
