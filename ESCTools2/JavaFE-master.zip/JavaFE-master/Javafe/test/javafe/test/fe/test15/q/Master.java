package q;

public class Master {}
