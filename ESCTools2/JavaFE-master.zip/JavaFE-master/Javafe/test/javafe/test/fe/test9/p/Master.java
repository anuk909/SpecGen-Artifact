package p;


// Generate a reference to p.TheFile:
class Master extends TheFile {}
