class C {

  // No enclosing unlabelled loop statement 
  void m() { break; }
  void m() { continue; }
