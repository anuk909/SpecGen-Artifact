interface I extends I {}	// error

