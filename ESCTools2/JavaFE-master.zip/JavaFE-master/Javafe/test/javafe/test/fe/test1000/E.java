class E {
  void j() {
  x: 
    j(); 
  x:
    j();
  }
}
