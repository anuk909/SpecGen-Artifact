package java.lang;

class Object extends Object {}		// no error

