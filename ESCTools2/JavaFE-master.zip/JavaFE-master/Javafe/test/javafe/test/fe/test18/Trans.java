class Trans extends Loop {}		// error (Loop is cyclic)
