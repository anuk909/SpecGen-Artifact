package strange.example;

import java.util.Vector;
import Vector.Mosquito;

class Test {
    public static void main(String[] args) {
	System.out.print(new Vector().getClass());
	System.out.print(new Mosquito().getClass());
    }
}
