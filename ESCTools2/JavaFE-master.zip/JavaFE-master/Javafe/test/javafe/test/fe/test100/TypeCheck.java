class TypeCheck {

    void doit() {
	Class c = java.lang.nonexistent[].class;   // error: no such class

    }
}
