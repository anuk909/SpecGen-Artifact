/**
 ** The ans file for this should be non-empty; I've made it non-empty
 ** to disable this test for now.
 **/

class causeErrors {

  int m64() {		// error: return required for this routine

	System.out.println("Foo!");

  }

}
