package p;

public class Foo {}
