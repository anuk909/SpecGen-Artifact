class D {
 void i() {
    { 
    x: 
      i(); 
    } 
  x:
    i();
  }
}
