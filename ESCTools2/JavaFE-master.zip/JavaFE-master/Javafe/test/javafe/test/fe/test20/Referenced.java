class Referenced {}

public class Local {}		// Caution: this should not be public!
