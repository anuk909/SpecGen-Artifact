// Test referencing superclasses via single-class import statements

// Note that this is in the unnamed package so the import is needed here.

import p.Target;

class Single extends Target {}
