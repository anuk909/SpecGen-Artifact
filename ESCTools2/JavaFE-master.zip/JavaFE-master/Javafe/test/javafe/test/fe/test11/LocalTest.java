// In the unnamed package

class LocalTest extends LocalTop {}
