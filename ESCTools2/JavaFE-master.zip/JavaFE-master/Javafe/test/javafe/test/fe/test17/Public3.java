import p.Private;	// error: Private not accessible here
// javac gets this one wrong too.

class Public3 {}
