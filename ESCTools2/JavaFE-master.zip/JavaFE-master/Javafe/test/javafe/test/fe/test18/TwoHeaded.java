interface Body extends Head, Head {}	// error -- javac is wrong here

interface Head {}
