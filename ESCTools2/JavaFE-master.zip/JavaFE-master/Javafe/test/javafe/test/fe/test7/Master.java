// Check handling of missing required Java language classes


class Master {

    Object x = "hello there";	// Reference java.lang.Object,String

}
