package Vector;

public class Mosquito { int capacity; }

