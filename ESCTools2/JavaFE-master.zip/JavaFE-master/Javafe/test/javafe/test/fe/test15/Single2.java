// In the unnamed package...

import q.Master;
import r.Master;	// An error

class Single2 {}
