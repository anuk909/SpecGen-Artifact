class Simple extends Simple {}		// error
