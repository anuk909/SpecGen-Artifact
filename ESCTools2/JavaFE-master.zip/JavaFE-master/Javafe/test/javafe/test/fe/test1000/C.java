class C {
  // bug in javac, is accepted
  // ok in javafe
  void h() {
  x: 
  x: 
    h();
  }
}
