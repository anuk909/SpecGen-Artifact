package java.lang;

class Object extends Exception {}		// error!
