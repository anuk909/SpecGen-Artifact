class C {
  void m() {
    if( true )
      int i;
    }
}
