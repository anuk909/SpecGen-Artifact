package foobar.bax;		// The wrong package name!

class Referenced {}
