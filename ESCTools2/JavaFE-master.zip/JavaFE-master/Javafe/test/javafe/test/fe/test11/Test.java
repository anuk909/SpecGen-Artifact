package p;

class Test extends Top {}
