class Top {
    void foo() {
	abstract interface         // parse error (ok, I guess...)
	    AbstInterface {}

	// Continued in Modifiers3c.java...
    }
}
