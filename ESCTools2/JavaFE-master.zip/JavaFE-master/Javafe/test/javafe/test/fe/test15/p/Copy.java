package p;

public class Copy {}
