package p;

class C extends A {}		// no error

class D extends B {}		// error!

class E extends A {}		// no error
