// In the unnamed package...

import p.Copy;

class Copy {}			// An error

class Single {}
