package p;

import Foo;		// erroneous because <unnamed>.Foo does not exist

class Full {}
