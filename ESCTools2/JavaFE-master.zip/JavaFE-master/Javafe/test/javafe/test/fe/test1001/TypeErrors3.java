class causeErrors {

  void m63() {

    // Enclosing statement labelled '...' is not a while, do, or for statement
  x: 
    continue x;			// caution

  }

}
