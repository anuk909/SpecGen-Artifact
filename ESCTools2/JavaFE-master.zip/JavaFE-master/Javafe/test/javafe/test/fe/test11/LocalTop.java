// In the unnamed package

class LocalTop {}
