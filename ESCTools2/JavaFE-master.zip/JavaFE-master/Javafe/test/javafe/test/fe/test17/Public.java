class Public extends p.Private {}	// error: Private not accessible here
