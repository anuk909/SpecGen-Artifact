package p;

class A extends B {}

class B {}
