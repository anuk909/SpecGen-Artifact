package P.Q;

class C {  // class (P.Q).C
    static boolean f = false;
    static boolean g = false;
   
}
