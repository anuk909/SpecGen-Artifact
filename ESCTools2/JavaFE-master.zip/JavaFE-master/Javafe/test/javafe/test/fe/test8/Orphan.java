class Orphan extends DeadParent {}	// Error: DeadParent does not exist!
