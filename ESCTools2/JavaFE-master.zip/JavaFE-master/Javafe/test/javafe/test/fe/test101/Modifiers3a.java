class Top {
    void foo() {
	synchronized class    // parse error
	    SyncClass {}

	// Continued in Modifiers3b.java...
    }
}
