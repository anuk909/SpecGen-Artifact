import java.lang.*;		// Not an error
import java.lang.*;		// Not an error

class JavaLang2 extends Exception {}	// Even when we use a class...
