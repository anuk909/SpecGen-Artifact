/*
 * This test makes sure a Tool handles duplicate declarations of a type
 * in two different source files on the command line properly.
 */

class Duplicated {}	// This declaration occurs twice...
