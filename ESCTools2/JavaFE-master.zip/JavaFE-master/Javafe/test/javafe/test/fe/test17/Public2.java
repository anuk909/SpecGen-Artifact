package p;

class Public2 extends Private {}		// no error
