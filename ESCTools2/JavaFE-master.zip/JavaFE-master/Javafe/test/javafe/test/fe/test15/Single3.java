// In the unnamed package...

import Copy;			// no error

class Copy {}			// no error

class Single {}
