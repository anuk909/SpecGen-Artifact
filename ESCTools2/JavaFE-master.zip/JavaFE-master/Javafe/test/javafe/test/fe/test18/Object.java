package java.lang;

class Object {}		// no error

