package foo.bar;

final class B {}

class A extends B {}		// error
