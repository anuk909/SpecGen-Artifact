// Test illegal import statements

import p.NoSuchPackage.*;		// error

class Package {}
