class G {
  void l() {
  x: 
  y:
    l(); 
  }
}
