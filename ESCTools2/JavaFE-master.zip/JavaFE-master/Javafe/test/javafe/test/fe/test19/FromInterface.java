package foo.bar;

interface B {}

class A extends B {}		// error
