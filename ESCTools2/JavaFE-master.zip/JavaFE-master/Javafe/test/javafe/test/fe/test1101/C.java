
class C extends Thread {

}

