package p;

class Otherwise {}

// Note that no class Referenced appears in this file...
