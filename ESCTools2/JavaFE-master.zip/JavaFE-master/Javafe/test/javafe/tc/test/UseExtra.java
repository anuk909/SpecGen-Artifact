package javafe.tc.test;

class UseExtra extends ExtraBinTest {

}
