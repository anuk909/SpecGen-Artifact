package javafe.tc.test;

class A {}

class A1 {}

class A2 {}

class A3 extends C {}
