package javafe.tc.test;

class A {}
