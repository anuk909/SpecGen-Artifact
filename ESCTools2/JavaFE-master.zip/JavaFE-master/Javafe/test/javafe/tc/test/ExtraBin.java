package javafe.tc.test;

class ExtraBin {}

// class ExtraBinTest {}
